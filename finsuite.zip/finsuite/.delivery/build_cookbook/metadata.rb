name             'databag_pipeline'
maintainer       'Ali'
maintainer_email 'None'
license          'Apache 2.0'
description      'Delivery build_cookbook for your data bags!'

version          '1.0.0'

supports 'ubuntu', '>= 12.04'
supports 'redhat', '>= 6.5'
supports 'centos', '>= 6.5'

depends 'delivery-sugar'
