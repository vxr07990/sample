name 'build_cookbook'
maintainer 'Thomas Polliard'
maintainer_email 'thomas.polliard@jmfamily.com'
license 'gplv3'
version '0.1.0'

depends 'delivery-truck'
